mod m1;
mod m2; 

fn main() {
    println!("trying to write from main dot rs");
    m1::room();
    m2::home();
}
